import controller.ContatoController;

public class App {
    public static void main(String[] args) throws Exception {
        ContatoController controller = new ContatoController();
        
        controller.iniciar();
    }
}
